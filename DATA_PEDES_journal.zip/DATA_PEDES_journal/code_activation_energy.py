import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import linregress
import os
from matplotlib.ticker import FormatStrFormatter


# ---------------- USER INPUT ----------------

input_excel = r"E:\Sarbani\PEDES_journal\UNISA\DATA_PEDES_journal\activation_energy_input.xlsx"
output_excel = r"E:\Sarbani\PEDES_journal\UNISA\DATA_PEDES_journal\Ea_result\results_new_plot.xlsx"
plot_folder = r"E:\Sarbani\PEDES_journal\UNISA\DATA_PEDES_journal\Ea_result"

R_g = 8.314  # J/mol/K
# --------------------------------------------

os.makedirs(plot_folder, exist_ok=True)
# ---------------- MATPLOTLIB STYLE ----------------
plt.rcParams.update({
    "font.family": "Times New Roman",

    # Axis labels & ticks
    "axes.labelsize": 32,
    "xtick.labelsize": 32,
    "ytick.labelsize": 32,

    # Legend
    "legend.fontsize": 32,

    # Line widths
    "axes.linewidth": 2.5,
    "xtick.major.width": 2.5,
    "ytick.major.width": 2.5,
    "xtick.major.size": 10,
    "ytick.major.size": 10,

    # ✅ Ensure math text (ln, subscripts, numbers) also uses Times New Roman
    "mathtext.fontset": "custom",
    "mathtext.rm": "Times New Roman",
    "mathtext.it": "Times New Roman:italic",
    "mathtext.bf": "Times New Roman:bold"
})

# Read all sheets
all_sheets = pd.read_excel(input_excel, sheet_name=None)

resistance_cols = ["Rohm", "Rsei", "Rct"]
results = []

# -------- Loop over sheets --------
for sheet_name, df in all_sheets.items():

    print(f"Processing sheet: {sheet_name}")

    df = df.iloc[:, :4].copy()
    df.columns = ["Temp_C", "Rohm", "Rsei", "Rct"]

    # Temperature conversion
    df["Temp_K"] = df["Temp_C"] + 273.15
    df["1000_over_T"] = 1000 / df["Temp_K"]

    for col in resistance_cols:

        x = df["1000_over_T"]
        y = np.log(1 / df[col])

        slope, intercept, r_value, _, _ = linregress(x, y)
        r2 = r_value**2
        Ea = -slope * R_g  # kJ/mol

        results.append({
            "Sheet_Name": sheet_name,
            "Parameter": col,
            "Slope": slope,
            "Intercept": intercept,
            "R_squared": r2,
            "Ea_J_per_mol": Ea * 1000,
            "Ea_kJ_per_mol": Ea
        })

        # ---------------- Plot ----------------
        plt.figure(figsize=(11, 9))

        # Scatter (changed color)
        plt.scatter(
            x, y,
            s=160,
            color="#1f4ed8",  # dark blue
            zorder=3,
            label="Experimental data"
        )

        # Fit line (changed color)
        y_fit = slope * x + intercept
        plt.plot(
            x,
            y_fit,
            color="#b11226",  # dark red
            linewidth=4,
            label=f"Linear fit  ($R^2 = {r2:.4f}$)"
        )

        # ---------- Increase Y-axis range ----------
        y_all = np.concatenate([y.values, y_fit.values])
        y_min, y_max = y_all.min(), y_all.max()
        y_margin = 1 * (y_max - y_min)
        plt.ylim(y_min - y_margin, y_max + y_margin)
        # ---- Force x-ticks to actual x-axis values ----
        x_ticks = np.sort(x.unique())
        plt.xticks(x_ticks)


        plt.xlabel(r"$1000/T\ \mathrm{(K^{-1})}$")
        plt.gca().xaxis.set_major_formatter(FormatStrFormatter('%.2f'))


        if col == "Rct":
            plt.ylabel(r"$\ln(1/R_{\mathrm{ct}})$")
        elif col == "Rsei":
            plt.ylabel(r"$\ln(1/R_{\mathrm{SEI}})$")
        elif col == "Rohm":
            plt.ylabel(r"$\ln(1/R_{\mathrm{ohm}})$")

        plt.grid(True, linestyle="--", linewidth=1.0)
        plt.legend(loc="best", frameon=False)
        plt.tight_layout()

        plot_path_png = os.path.join(
            plot_folder, f"{sheet_name}_{col}_Arrhenius.png"
        )
        plot_path_pdf = os.path.join(
            plot_folder, f"{sheet_name}_{col}_Arrhenius.pdf"
        )

        plt.savefig(plot_path_png, dpi=600, bbox_inches="tight")
        plt.savefig(plot_path_pdf, dpi=600, bbox_inches="tight")
        plt.close()

# -------- Save results to Excel --------
results_df = pd.DataFrame(results)
results_df.to_excel(output_excel, index=False)

print("====================================")
print("Analysis complete.")
print("Results saved to:", output_excel)
print("Plots saved in folder:", plot_folder)
print("====================================")
