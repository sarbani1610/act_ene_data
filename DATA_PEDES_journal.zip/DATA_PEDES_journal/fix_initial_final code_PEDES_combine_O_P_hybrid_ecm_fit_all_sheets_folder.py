# hybrid_ecm_fit_all_sheets_folder.py

import numpy as np
import pandas as pd
import os
import matplotlib.pyplot as plt
from scipy.optimize import differential_evolution, least_squares

# ==========================================================
# USER SETTINGS
# ==========================================================
input_folder = r"E:\Sarbani\PEDES_journal\UNISA\DATA_PEDES_journal\EIS_input"
output_base_folder = r"E:\Sarbani\PEDES_journal\UNISA\DATA_PEDES_journal\EIS_input"
output_excel = os.path.join(output_base_folder, "ECM_results_all_files.xlsx")

freq_col = "Frequency"
zreal_col = "Zreal"
zimg_col = "Zimg"

# skiprows = [35, 36, 37, 38, 39, 40, 41, 42]
skiprows = [100]
os.makedirs(output_base_folder, exist_ok=True)

# ==========================================================
# ECM MODEL
# ==========================================================
def ecm_model(params, freq):
    R1, R2, R3, T1, T2, P1, P2, Rw0, Two = params
    w = 2 * np.pi * freq
    j = 1j

    Zcpe1 = R2 / (1 + (R2 * T1 * (j * w) ** P1))
    Zcpe2 = R3 / (1 + (R3 * T2 * (j * w) ** P2))

    sqrt_term = (j * Two * w) ** 0.5
    with np.errstate(divide='ignore', invalid='ignore'):
        Zw = Rw0 * ((np.cosh(sqrt_term) / np.sinh(sqrt_term)) / sqrt_term)
        Zw = np.nan_to_num(Zw)

    return R1 + Zcpe1 + Zcpe2 + Zw

# ==========================================================
# COST FUNCTIONS (R1 FIXED)
# ==========================================================
def cost_for_de(params, freq, Zr, Zi, R1_fixed):
    params = params.copy()
    params[0] = R1_fixed
    Zp = ecm_model(params, freq)
    return np.sum((Zr - Zp.real)**2 + (Zi - Zp.imag)**2)

def residuals_for_lm(params, freq, Zr, Zi, R1_fixed):
    params = params.copy()
    params[0] = R1_fixed
    Zp = ecm_model(params, freq)
    return np.concatenate([(Zr - Zp.real), (Zi - Zp.imag)])

# ==========================================================
# BOUNDS
# ==========================================================
# final for Panasonic good ECM

bounds = [
    (0.02, .07),
    (0.001, 1.0),
    (0.0001, 1.0),
    (0.01, 50.0),
    (0.01, 80.0),
    (0.09, 1),
    (0.09, 1),
    (1e-6, 10.0),
    (0, 100.0)
]

lb = np.array([b[0] for b in bounds])
ub = np.array([b[1] for b in bounds])

# ==========================================================
# LOOP OVER ALL EXCEL FILES
# ==========================================================
# excel_files = [
#     f for f in os.listdir(input_folder)
#     if f.endswith((".xlsx", ".xls"))
# ]
excel_files = [
    f for f in os.listdir(input_folder)
    if f.endswith((".xlsx", ".xls")) and not f.startswith("~$")
]

with pd.ExcelWriter(output_excel, engine="xlsxwriter") as writer:

    for excel_file in excel_files:

        input_excel_path = os.path.join(input_folder, excel_file)
        file_key = os.path.splitext(excel_file)[0][:31]

        # 🔹 create output folder PER FILE
        file_output_folder = os.path.join(
            output_base_folder,
            f"OUT_{file_key}"
        )
        os.makedirs(file_output_folder, exist_ok=True)

        print(f"\n📂 Processing file: {excel_file}")

        xls = pd.ExcelFile(input_excel_path)
        sheet_names = xls.sheet_names

        all_rows = []

        for sheet_name in sheet_names:

            print(f"   ▶ Sheet: {sheet_name}")

            df = pd.read_excel(
                input_excel_path,
                sheet_name=sheet_name,
                skiprows=skiprows
            )

            freq = df[freq_col].to_numpy(float)
            Z_real = df[zreal_col].to_numpy(float)
            Z_imag = df[zimg_col].to_numpy(float)
            N = len(freq)

            # --------------------------
            # R1 from HF intercept
            # --------------------------
            sign_change_idx = np.where(np.diff(np.sign(Z_imag)) != 0)[0]
            R1_data = Z_real[sign_change_idx[-1]] if len(sign_change_idx) else Z_real[-1]

            # --------------------------
            # Differential Evolution
            
            result_de = differential_evolution(
                lambda p: cost_for_de(p, freq, Z_real, Z_imag, R1_data),
                bounds,
                maxiter=2000,
                popsize=25,
                tol=1e-7,
                mutation=(0.5, 1),
                recombination=0.7,
                polish=False,
                seed=42          # ✅ fixed seed for reproducibility
            )

            # --------------------------
            # LM / TRF refinement
            # --------------------------
            try:
                res_lm = least_squares(
                    lambda p: residuals_for_lm(p, freq, Z_real, Z_imag, R1_data),
                    result_de.x,
                    method='lm',
                    max_nfev=2000
                )
                params = res_lm.x
                if np.any((params < lb) | (params > ub)):
                    raise ValueError
            except:
                res_lm = least_squares(
                    lambda p: residuals_for_lm(p, freq, Z_real, Z_imag, R1_data),
                    result_de.x,
                    bounds=(lb, ub),
                    method='trf',
                    max_nfev=2000
                )
                params = res_lm.x

            params[0] = R1_data

            # --------------------------
            # Metrics
            # --------------------------
            Z_fit = ecm_model(params, freq)

            RMSE = np.sqrt(np.mean(
                (Z_real - Z_fit.real)**2 +
                (Z_imag - Z_fit.imag)**2
            ))

            k = len(params)
            eps = 1e-20
            AIC = 2*k + N*np.log(RMSE**2 + eps)
            BIC = k*np.log(N) + N*np.log(RMSE**2 + eps)
            AICc = AIC + (2*k*(k+1))/(N-k-1) if N > k+1 else np.nan

            all_rows.append({
                "InputSheet": sheet_name,
                "R1": params[0],
                "R2": params[1],
                "R3": params[2],
                "T1": params[3],
                "T2": params[4],
                "P1": params[5],
                "P2": params[6],
                "Rw0": params[7],
                "Two": params[8],
                "RMSE": RMSE,
                "AIC": AIC,
                "BIC": BIC,
                "AICc": AICc
            })

            # --------------------------
            # Nyquist plot (per sheet)
            # --------------------------
            plt.figure(figsize=(6,6))
            plt.plot(Z_real, -Z_imag, 'o', label="Measured")
            plt.plot(Z_fit.real, -Z_fit.imag, '-', label="ECM fit")
            plt.xlabel("Z' (Ohm)")
            plt.ylabel("-Z'' (Ohm)")
            plt.title(f"Nyquist – {sheet_name}")
            plt.axis("equal")
            plt.grid(True)
            plt.legend()

            fig_path = os.path.join(
                file_output_folder,
                f"Nyquist_{sheet_name}.png"
            )
            plt.savefig(fig_path, dpi=300, bbox_inches="tight")
            plt.close()

        # --------------------------
        # WRITE ONE SHEET PER FILE
        # --------------------------
        pd.DataFrame(all_rows).to_excel(
            writer,
            sheet_name=file_key,
            index=False
        )

        print(f"✅ Finished file: {excel_file}")

print("\n🎯 All files processed successfully")
print(f"📊 Output Excel: {output_excel}")
